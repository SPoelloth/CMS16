<?php
$t= "../" . $_POST['name'];
echo $t;
unlink($t); 
?>